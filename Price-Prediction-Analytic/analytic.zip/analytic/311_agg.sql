!connect jdbc:hive2://babar.es.its.nyu.edu:10000/
<insert username>
<insert password>
use <username>;
show tables;
select * from w10;

